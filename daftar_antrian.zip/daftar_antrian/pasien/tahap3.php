<?php
session_start();
include '../config/koneksi.php';

/* ================= CEK SESSION ================= */
if (!isset($_SESSION['pasien']) || !isset($_SESSION['kunjungan'])) {
    header("Location: tahap1.php");
    exit;
}

$pasien    = $_SESSION['pasien'];
$kunjungan = $_SESSION['kunjungan'];

/* ================= DATA POLI ================= */
$poliNama   = '-';
$lokasiPoli = '-';

$poliQ = mysqli_query($conn, "
    SELECT nama_poli, lokasi_poli 
    FROM poli 
    WHERE id_poli = '{$kunjungan['id_poli']}'
");

if ($poliQ && mysqli_num_rows($poliQ) > 0) {
    $poli = mysqli_fetch_assoc($poliQ);
    $poliNama   = $poli['nama_poli'];
    $lokasiPoli = $poli['lokasi_poli'];
}

/* ================= DATA DOKTER ================= */
$namaDokter = '-';

if (!empty($kunjungan['id_dokter'])) {
    $dokterQ = mysqli_query($conn, "
        SELECT nama_dokter 
        FROM dokter 
        WHERE id_dokter = '{$kunjungan['id_dokter']}'
    ");

    if ($dokterQ && mysqli_num_rows($dokterQ) > 0) {
        $dokter = mysqli_fetch_assoc($dokterQ);
        $namaDokter = $dokter['nama_dokter'];
    }
}

/* ================= SIMPAN + CETAK ================= */
if (isset($_POST['simpan_cetak'])) {

    // SIMPAN PASIEN
    mysqli_query($conn, "
        INSERT INTO pasien
        (nik, nama_pasien, jenis_kelamin, tanggal_lahir, no_hp, jenis_penjamin)
        VALUES
        (
            '{$pasien['nik']}',
            '{$pasien['nama']}',
            '{$pasien['jk']}',
            '{$pasien['tgl']}',
            '{$pasien['hp']}',
            'Umum'
        )
    ");

    $id_pasien = mysqli_insert_id($conn);

    // SIMPAN KUNJUNGAN
    mysqli_query($conn, "
        INSERT INTO kunjungan
        (id_pasien, id_poli, id_dokter, tanggal_kunjungan)
        VALUES
        (
            '$id_pasien',
            '{$kunjungan['id_poli']}',
            '{$kunjungan['id_dokter']}',
            CURDATE()
        )
    ");

    $id_kunjungan = mysqli_insert_id($conn);

    // HAPUS SESSION
    unset($_SESSION['pasien'], $_SESSION['kunjungan']);

    // REDIRECT KE CETAK
    header("Location: cetak.php?id=".$id_kunjungan);
    exit;
}

/* ================= TAMPILAN ================= */
$title = "Tahap 3 - Konfirmasi";

$content = '
<div class="card card-rs shadow">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">Konfirmasi Pendaftaran</h5>
    </div>

    <div class="card-body">

        <h6 class="fw-bold mb-3">Data Pasien</h6>
        <table class="table table-bordered">
            <tr><th>Nama</th><td>'.$pasien['nama'].'</td></tr>
            <tr><th>NIK</th><td>'.$pasien['nik'].'</td></tr>
            <tr><th>Jenis Kelamin</th><td>'.$pasien['jk'].'</td></tr>
            <tr><th>Tanggal Lahir</th><td>'.$pasien['tgl'].'</td></tr>
            <tr><th>No HP</th><td>'.$pasien['hp'].'</td></tr>
        </table>

        <h6 class="fw-bold mt-4 mb-3">Tujuan Kunjungan</h6>
        <table class="table table-bordered">
            <tr><th>Poli</th><td>'.$poliNama.'</td></tr>
            <tr><th>Lokasi Poli</th><td>'.$lokasiPoli.'</td></tr>
            <tr><th>Dokter</th><td>'.$namaDokter.'</td></tr>
        </table>

        <form method="post" class="d-flex justify-content-between">
            <a href="tahap2.php" class="btn btn-secondary">
                ← Kembali
            </a>

            <button type="submit" name="simpan_cetak" class="btn btn-success">
                Simpan & Cetak
            </button>
        </form>

    </div>
</div>
';

include '../template/template.php';
