<?php include '../config/koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<div class="container">
    <h2>Tambah Data Mahasiswa</h2>

    <form method="post" action="proses_tambah.php" class="form-box">
      <label>ID</label>
      <input type="text" name="id">

      <label>Nama</label>
      <input type="text" name="nama">

      <label>NIM</label>
      <input type="text" name="nim">

      <label>Jurusan</label>
      <input type="text" name="jurusan">

      <button type="submit">Simpan</button>
    </form>
</div>

<div class="container">
<h2>Daftar Pasien Poli Mata</h2>

<?php
$result = mysqli_query($conn, "SELECT * FROM pendaftaran");
?>
 <?php while ($row = mysqli_fetch_assoc($result)) :
        if ($row["Poli"]=="mata") {
            $mata[]=$row;
        }
        if ($row["Poli"]=="umum") {
            $umum[]=$row;
        }
    endwhile;
     echo"<p>"; print_r($mata);
     Echo "</p>";
     ?>
<table>
    <tr>
        <th>id_pendaftaran</th>
        <th>kode_pendaftaran</th>
        <th>id_pasien</th>
        <th>tanggal_kunjungan</th>
        <th>Poli</th>
    </tr>

    <?php foreach ($mata as $row){ ?>
        <tr>
            <td><?= $row['id_pendaftaran']; ?></td>
            <td><?= $row['kode_pendaftaran']; ?></td>
            <td><?= $row['id_pasien']; ?></td>
            <td><?= $row['tanggal_kunjungan']; ?></td>
            <td><?= $row['Poli']; ?></td>
            <td>
            </td>
        </tr>
    <?php } ?>
</table>
<h2>Daftar Pasien Poli umum</h2>
<table>
    <tr>
        <th>id_pendaftaran</th>
        <th>kode_pendaftaran</th>
        <th>id_pasien</th>
        <th>tanggal_kunjungan</th>
        <th>Poli</th>
    </tr>

    <?php foreach ($umum as $row){ ?>
        <tr>
            <td><?= $row['id_pendaftaran']; ?></td>
            <td><?= $row['kode_pendaftaran']; ?></td>
            <td><?= $row['id_pasien']; ?></td>
            <td><?= $row['tanggal_kunjungan']; ?></td>
            <td><?= $row['Poli']; ?></td>
            <td>
            </td>
        </tr>
    <?php } ?>
</table>
</div>

</body>
</html>

</body>
</html>