<?php
session_start();
include '../config/koneksi.php';

/* AMBIL DATA DARI SESSION / POST */
$id_poli   = $_POST['id_poli'] ?? ($_SESSION['kunjungan']['id_poli'] ?? '');
$id_dokter = $_POST['id_dokter'] ?? ($_SESSION['kunjungan']['id_dokter'] ?? '');

/* AMBIL LOKASI POLI */
$lokasi_poli = '';
if ($id_poli != '') {
    $q = mysqli_query($conn, "SELECT lokasi_poli FROM poli WHERE id_poli='$id_poli'");
    if ($q && mysqli_num_rows($q) > 0) {
        $d = mysqli_fetch_assoc($q);
        $lokasi_poli = $d['lokasi_poli'];
    }
}

/* =========================
   SIMPAN SESSION SAAT LANJUT
   ========================= */
if (isset($_POST['lanjut'])) {
    $_SESSION['kunjungan'] = [
        'id_poli'     => $id_poli,
        'id_dokter'   => $id_dokter,
        'lokasi_poli' => $lokasi_poli
    ];

    header("Location: tahap3.php");
    exit;
}

$title = "Tahap 2 - Pilih Poli";

$content = '
<div class="card card-rs shadow">
    <div class="card-header bg-primary text-white">
        <h5>Tujuan Kunjungan</h5>
    </div>

    <div class="card-body">
        <form method="post">

            <!-- POLI -->
            <div class="mb-3">
                <label class="form-label fw-bold">Pilih Poli</label>
                <select name="id_poli" class="form-select" required onchange="this.form.submit()">
                    <option value="">-- Pilih Poli --</option>';
                    
$poli = mysqli_query($conn, "SELECT * FROM poli");
while ($p = mysqli_fetch_assoc($poli)) {
    $selected = ($p['id_poli'] == $id_poli) ? 'selected' : '';
    $content .= "<option value='{$p['id_poli']}' $selected>{$p['nama_poli']}</option>";
}

$content .= '
                </select>
            </div>

            <!-- LOKASI POLI -->
            <div class="mb-3">
                <label class="form-label fw-bold">Lokasi Poli</label>
                <input type="text" class="form-control bg-light"
                       value="'.htmlspecialchars($lokasi_poli).'" readonly>
            </div>

            <!-- DOKTER -->
            <div class="mb-3">
                <label class="form-label fw-bold">Dokter</label>
                <select name="id_dokter" class="form-select" required>';

if ($id_poli != '') {
    $dokter = mysqli_query($conn, "
        SELECT * FROM dokter
        WHERE id_poli='$id_poli'
        AND status_dokter='aktif'
    ");

    if (mysqli_num_rows($dokter) > 0) {
        $content .= '<option value="">-- Pilih Dokter --</option>';
        while ($d = mysqli_fetch_assoc($dokter)) {
            $sel = ($d['id_dokter'] == $id_dokter) ? 'selected' : '';
            $content .= "<option value='{$d['id_dokter']}' $sel>{$d['nama_dokter']}</option>";
        }
    } else {
        $content .= '<option value="">Dokter tidak tersedia</option>';
    }
} else {
    $content .= '<option value="">-- Pilih Poli Dulu --</option>';
}

$content .= '
                </select>
            </div>

            <div class="d-flex justify-content-between">
                <a href="tahap1.php" class="btn btn-secondary">← Kembali</a>
                <button type="submit" name="lanjut" class="btn btn-success">
                    Lanjut →
                </button>
            </div>

        </form>
    </div>
</div>
';

include '../template/template.php';
