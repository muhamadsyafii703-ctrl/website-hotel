<?php
session_start();
include '../config/koneksi.php';

/* ================= RESET JIKA PASIEN BARU ================= */
if (!isset($_POST['lanjut'])) {
    unset($_SESSION['pasien']);
    unset($_SESSION['kunjungan']);
}


/* SIMPAN KE SESSION */
if (isset($_POST['lanjut'])) {
    $_SESSION['pasien'] = [
        'nama' => $_POST['nama'],
        'nik'  => $_POST['nik'],
        'jk'   => $_POST['jk'],
        'tgl'  => $_POST['tgl_lahir'],
        'hp'   => $_POST['hp']
    ];
    header("Location: tahap2.php");
    exit;
}

/* AMBIL DATA */
$pasien = $_SESSION['pasien'] ?? [
    'nama' => '',
    'nik'  => '',
    'jk'   => '',
    'tgl'  => '',
    'hp'   => '',
];

$title = "Pendaftaran Pasien";
include '../template/template.php';
?>

<!-- ================= HTML MULAI DI SINI ================= -->

<div class="container-fluid">

    <div class="card card-rs shadow">
        <div class="card-header bg-primary text-white text-center">
            <h4>Form Pendaftaran Pasien</h4>
        </div>

        <div class="card-body">

            <form method="post">

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nama</label>
                        <input type="text" name="nama" class="form-control"
                               value="<?= htmlspecialchars($pasien['nama']) ?>" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">NIK</label>
                        <input type="text" name="nik" class="form-control"
                               value="<?= htmlspecialchars($pasien['nik']) ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Jenis Kelamin</label>
                        <select name="jk" class="form-select" required>
                            <option value="">-- Pilih --</option>
                            <option value="Laki-Laki" <?= $pasien['jk']=='Laki-Laki'?'selected':'' ?>>Laki-laki</option>
                            <option value="Perempuan" <?= $pasien['jk']=='Perempuan'?'selected':'' ?>>Perempuan</option>
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tanggal Lahir</label>
                        <input type="date" name="tgl_lahir" class="form-control"
                               value="<?= $pasien['tgl'] ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">No HP</label>
                        <input type="text" name="hp" class="form-control"
                               value="<?= htmlspecialchars($pasien['hp']) ?>" required>
                    </div>
                </div>

                <div class="d-flex justify-content-between">
                    <a href="?reset=1" class="btn btn-outline-danger btn-sm">Reset</a>

                    <button type="submit" name="lanjut" class="btn btn-primary">
                        Lanjut →
                    </button>

                </div>

            </form>

        </div>
    </div>

</div>

