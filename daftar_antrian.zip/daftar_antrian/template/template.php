<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= $title ?? 'RSUD Online'; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {  background-image: url('/rsudjombang/assets/img/rumahsakit.jpg');
        background-size: cover;
        background-position: center; }
        .navbar-rs {
            background: linear-gradient(90deg, #0d6efd);
        }
        .card-rs {
            border-radius: 12px;
            border: none;
        }
        .btn-rs {
            border-radius: 30px;
            padding: 10px 20px;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-dark navbar-rs">
    <div class="container">
    <div class="d-flex align-items-center">
        <img src="/rsudjombang/assets/img/logo.png"
             alt="Logo RSUD Jombang"
             class="me-2"
             style="height:38px;">

        <div class="text-white lh-sm">
            <div class="fw-bold">RSUD Jombang</div>
            <small>Pelayanan Kesehatan Masyarakat</small>
        </div>
    </div>
    </div>
</nav>


<!-- KONTEN -->
<div class="container my-5">
    <?php if (isset($content)) echo $content; ?>
</div>

<!-- FOOTER -->
<footer class="text-center text-muted py-3">
    © <?= date('Y'); ?> RSUD Jombang
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
