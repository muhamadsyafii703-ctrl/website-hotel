<?php
require "koneksi.php";
date_default_timezone_set('Asia/Jakarta');

// Ambil enum
$sub_bidang_query = mysqli_query($koneksi, "SHOW COLUMNS FROM paket LIKE 'sub_bidang'");
$sub_bidang_row = mysqli_fetch_assoc($sub_bidang_query);
$sub_bidang_list = explode("','", str_replace(["enum('", "')"], "", $sub_bidang_row['Type']));

$satuan_query = mysqli_query($koneksi, "SHOW COLUMNS FROM paket LIKE 'satuan_kerja'");
$satuan_row = mysqli_fetch_assoc($satuan_query);
$satuan_list = explode("','", str_replace(["enum('", "')"], "", $satuan_row['Type']));

$pesan = "";

if (isset($_POST['simpan'])) {

    $nama_paket   = trim($_POST['nama_paket']);
    $satuan_kerja = $_POST['satuan_kerja'];
    $sub_bidang   = $_POST['sub_bidang'];
    $harga_awal   = $_POST['harga_awal'];
    $expired      = $_POST['expired'];

    // CEK DUPLIKAT NAMA PAKET
    $cek = mysqli_query($koneksi, "SELECT id FROM paket WHERE nama_paket = '$nama_paket'");
    if (mysqli_num_rows($cek) > 0) {
        $pesan = "❌ Nama paket sudah digunakan. Gunakan nama lain.";
    } else {
        $query = "INSERT INTO paket 
            (nama_paket, satuan_kerja, sub_bidang, harga_awal, expired)
            VALUES 
            ('$nama_paket', '$satuan_kerja', '$sub_bidang', '$harga_awal', '$expired')";

        if (mysqli_query($koneksi, $query)) {
            $pesan = "✅ Data berhasil disimpan.";
            header("Refresh:1; url=index.php");
        } else {
            $pesan = "❌ Gagal menyimpan data.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Input Paket</title>
<link href="./bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="container mt-5">
<div class="card shadow">
<div class="card-header bg-primary text-white">
    <h5 class="mb-0">Input Paket Tender</h5>
</div>

<div class="card-body">

<?php if (!empty($pesan)): ?>
    <div class="alert alert-info"><?= $pesan ?></div>
<?php endif; ?>

<form method="POST">

    <div class="mb-3">
        <label>Nama Paket</label>
        <input type="text" name="nama_paket" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Satuan Kerja</label>
        <select name="satuan_kerja" class="form-control" required>
            <option value="">-- Pilih --</option>
            <?php foreach ($satuan_list as $val): ?>
                <option value="<?= $val ?>"><?= $val ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Sub Bidang</label>
        <select name="sub_bidang" class="form-control" required>
            <option value="">-- Pilih --</option>
            <?php foreach ($sub_bidang_list as $val): ?>
                <option value="<?= $val ?>"><?= $val ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Harga Pagu</label>
        <input type="number" name="harga_awal" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Batas Waktu</label>
        <input type="datetime-local" name="expired" class="form-control" required>
    </div>

    <button type="submit" name="simpan" class="btn btn-success w-100">
        Simpan Data
    </button>
</form>

</div>
</div>
</div>

</body>
</html>
