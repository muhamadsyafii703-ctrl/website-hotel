<tr>
  <td><?= $row['id'] ?></td>
  <td><?= htmlspecialchars($row['nama_paket']) ?></td>
  <td><?= htmlspecialchars($row['sub_bidang']) ?></td>
  <td>Rp <?= number_format($row['harga_awal'], 0, ',', '.') ?></td>

  <!-- PENAWARAN -->
  <td>
    <?php
    $qPenawaran = mysqli_query($koneksi, "
        SELECT nama_rekanan, harga_penawaran
        FROM penawaran
        WHERE nama_paket = '".$row['nama_paket']."'
        ORDER BY harga_penawaran ASC
    ");
    $penawaran_terendah=0;


    if (mysqli_num_rows($qPenawaran) > 0) {
        while ($p = mysqli_fetch_assoc($qPenawaran)) {
            echo "<b>" . htmlspecialchars($p['nama_rekanan']) . "</b> : ";
            echo "Rp " . number_format($p['harga_penawaran'], 0, ',', '.') . "<br>";
            if($penawaran_terendah==0 OR $p['harga_penawaran']<$penawaran_terendah){
                $penawar_terendah=$p['nama_rekanan'];
                $penawaran_terendah=$p['harga_penawaran'];
            }
        }
        echo"<br><br><p><b>Penawaran Terendah<b>: <b>$penawar_terendah</b> : Rp " . number_format($penawaran_terendah, 0, ',', '.') ."</p>";
    } else {
        echo "<i>Belum ada penawaran</i>";
    }
  ?>
  </td>

  <!-- PEMENANG -->
  <td>
  <?php
  if ($expired <= $now) {
      $qWinner = mysqli_query($koneksi, "
          SELECT nama_rekanan, harga_penawaran 
          FROM penawaran 
          WHERE nama_paket = '".$row['nama_paket']."'
          ORDER BY harga_penawaran ASC
          LIMIT 1
      ");

      if ($winner = mysqli_fetch_assoc($qWinner)) {
          echo "<b>" . htmlspecialchars($winner['nama_rekanan']) . "</b><br>";
          echo "Rp " . number_format($winner['harga_penawaran'], 0, ',', '.');
          
          if(!isset($row['pemenang'])){
            $nama  = $winner['nama_rekanan'];
            $harga = $winner['harga_penawaran'];
            $id_paket =  $row['id'];
            // echo "<h2>$nama, $harga,$id_paket</h2>";
            $sql = "UPDATE paket SET pemenang=? , harga_terakhir=? WHERE id=?";
            $stmt = $koneksi->prepare($sql);
            $stmt->bind_param("sii", $nama, $harga, $id_paket);
            $stmt->execute();
            $stmt->close();
          }
      } else {
          echo "-";
      }
          $ajukan = "<span class='badge bg-secondary'>Tender Ditutup</span>";

  } else {
          $ajukan = "<a href='penawaran.php?id=$row[id]' class='btn btn-success btn-sm'>
        Ajukan Penawaran
      </a>";

      echo "<i>Belum ditentukan</i>";
  }
  ?>
  </td>

  <td>
    <?= ($expired <= $now)
        ? "<span class='badge bg-secondary'>Selesai</span>"
        : "<span class='badge bg-success'>Berjalan</span>" ?>
  </td>

  <td><?= $expired->format('d M Y H:i') ?></td>

  <td>
    <?php 
      $ajukan;
    
    ?>
    
  </td>
</tr>