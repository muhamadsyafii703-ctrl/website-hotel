<?php
require "koneksi.php";
date_default_timezone_set('Asia/Jakarta');
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>SPSE</title>
<link href="bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="container mt-4">

<div class="d-flex justify-content-end mb-2">
  <a href="input_paket.php" class="btn btn-primary">Pembuatan Proyek</a>
</div>

<table class="table table-bordered table-hover">
<thead class="table-dark">
<tr>
  <th>No</th>
  <th>Nama Paket</th>
  <th>Sub Bidang</th>
  <th>Nilai Pagu</th>
  <th>Penawaran</th>
  <th>Pemenang</th>
  <th>Status Tender</th>
  <th>Akhir Pendaftaran</th>
  <th>Aksi</th>
</tr>
</thead>

<tbody>
<?php
$query = mysqli_query($koneksi, "SELECT * FROM paket ORDER BY id DESC");
$no = 1;
$now = new DateTime();

while ($row = mysqli_fetch_assoc($query)) {

    $expired = new DateTime($row['expired']);
?>
<tr>
  <td><?= $no++ ?></td>
  <td><?= htmlspecialchars($row['nama_paket']) ?></td>
  <td><?= htmlspecialchars($row['sub_bidang']) ?></td>
  <td>Rp <?= number_format($row['harga_awal'], 0, ',', '.') ?></td>

  <!-- PENAWARAN -->
  <td>
  <?php
$qPenawaran = mysqli_query($koneksi, "
    SELECT nama_rekanan, harga_penawaran
    FROM penawaran
    WHERE nama_paket = '".$row['nama_paket']."'
    ORDER BY harga_penawaran ASC
");


  if (mysqli_num_rows($qPenawaran) > 0) {
      while ($p = mysqli_fetch_assoc($qPenawaran)) {
          echo "<b>" . htmlspecialchars($p['nama_rekanan']) . "</b> : ";
          echo "Rp " . number_format($p['harga_penawaran'], 0, ',', '.') . "<br>";
      }
  } else {
      echo "<i>Belum ada penawaran</i>";
  }
  ?>
  </td>

  <!-- PEMENANG -->
  <td>
  <?php
  if ($expired <= $now) {
      $qWinner = mysqli_query($koneksi, "
          SELECT nama_rekanan, harga_penawaran 
          FROM penawaran 
          WHERE nama_paket = '".$row['nama_paket']."'
          ORDER BY harga_penawaran ASC
          LIMIT 1
      ");

      if ($winner = mysqli_fetch_assoc($qWinner)) {
          echo "<b>" . htmlspecialchars($winner['nama_rekanan']) . "</b><br>";
          echo "Rp " . number_format($winner['harga_penawaran'], 0, ',', '.');
      } else {
          echo "-";
      }
  } else {
      echo "<i>Belum ditentukan</i>";
  }
  ?>
  </td>

  <td>
    <?= ($expired <= $now)
        ? "<span class='badge bg-secondary'>Selesai</span>"
        : "<span class='badge bg-success'>Berjalan</span>" ?>
  </td>

  <td><?= $expired->format('d M Y H:i') ?></td>

  <td>
    <?php if ($expired >= $now) { ?>
      <a href="penawaran.php?id=<?= $row['id'] ?>" class="btn btn-success btn-sm">
        Ajukan Penawaran
      </a>
    <?php } else { ?>
      <span class="badge bg-secondary">Tender Ditutup</span>
    <?php } ?>
  </td>
</tr>
<?php } ?>
</tbody>
</table>

</div>
</body>
</html>
