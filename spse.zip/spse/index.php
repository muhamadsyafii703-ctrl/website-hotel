<?php
require "koneksi.php";
date_default_timezone_set('Asia/Jakarta');
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>SPSE</title>
<link href="bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="container mt-4">

<div class="d-flex justify-content-end mb-2">
  <a href="input_paket.php" class="btn btn-primary">Pembuatan Proyek</a>
</div>

<table class="table table-bordered table-hover">
<thead class="table-dark">
<tr>
  <th>No</th>
  <th>Nama Paket</th>
  <th>Sub Bidang</th>
  <th>Nilai Pagu</th>
  <th>Penawaran</th>
  <th>Pemenang</th>
  <th>Status Tender</th>
  <th>Akhir Pendaftaran</th>
  <th>Aksi</th>
</tr>
</thead>

<tbody>
<?php
$query = mysqli_query($koneksi, "SELECT * FROM paket ORDER BY id DESC");
$no = 1;
$now = new DateTime();

while ($row = mysqli_fetch_assoc($query)) {
    $expired = new DateTime($row['expired']);
    require "index_isitabel.php";
} ?>
</tbody>
</table>

</div>
</body>
</html>
