-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2025 at 05:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spse`
--

-- --------------------------------------------------------

--
-- Table structure for table `paket`
--

CREATE TABLE `paket` (
  `id` int(11) NOT NULL,
  `satuan_kerja` enum('Dinas Pendidikan','Dinas Peternakan','Dinas Pertanian','Dinas Perindustrian dan Perdagangan Provinsi Jawa Timur','Dinas Pekerjaan Umum dan Penataan Ruang Kabupaten Mojokerto') NOT NULL,
  `nama_paket` varchar(225) NOT NULL,
  `sub_bidang` enum('1. 42101 Konstruksi Bangunan Sipil Jalan atau 2. 42102 Konstruksi Bangunan Sipil Jembatan, Jalan Layang, Fly Over, dan Underpass atau 3. 42111 Konstruksi Jalan Raya','Memiliki Sertifikat Badan Usaha Jasa Konstruksi SBUJK Kualifikasi Usaha Kecil yang masih berlaku Sub Klasifikasi BG009 Konstruksi Gedung Lainnya KBLI 41019','KBLI 46421 2020 Perdagangan Besar Alat Tulis Dan Gambar, KBLI 47611 2020 Perdagangan Eceran Alat Tulis Menulis dan Gambar, KBLI 46694 2020 Perdagangan Besar Kertas dan Karton, KBLI 46695 2020 Perdagangan Besar Barang Dari Kertas Dan Karton, atau KBLI 47650 2020 perdagangan eceran kertas, kertas karton, dan barang dari kertaskarton, Dengan kualifikasi usaha Mikro, Kecil, Menengah atau Besar') NOT NULL,
  `harga_awal` bigint(20) NOT NULL,
  `harga_terakhir` bigint(20) DEFAULT NULL,
  `pemenang` varchar(225) DEFAULT NULL,
  `expired` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `penawaran`
--

CREATE TABLE `penawaran` (
  `id` int(11) NOT NULL,
  `nama_rekanan` varchar(225) NOT NULL,
  `nama_paket` varchar(225) NOT NULL,
  `harga_penawaran` bigint(20) DEFAULT NULL,
  `sub_bidang` enum('1. 42101 Konstruksi Bangunan Sipil Jalan atau 2. 42102 Konstruksi Bangunan Sipil Jembatan, Jalan Layang, Fly Over, dan Underpass atau 3. 42111 Konstruksi Jalan Raya','Memiliki Sertifikat Badan Usaha Jasa Konstruksi SBUJK Kualifikasi Usaha Kecil yang masih berlaku Sub Klasifikasi BG009 Konstruksi Gedung Lainnya KBLI 41019','KBLI 46421 2020 Perdagangan Besar Alat Tulis Dan Gambar, KBLI 47611 2020 Perdagangan Eceran Alat Tulis Menulis dan Gambar, KBLI 46694 2020 Perdagangan Besar Kertas dan Karton, KBLI 46695 2020 Perdagangan Besar Barang Dari Kertas Dan Karton, atau KBLI 47650 2020 perdagangan eceran kertas, kertas karton, dan barang dari kertaskarton, Dengan kualifikasi usaha Mikro, Kecil, Menengah atau Besar','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `perusahaan` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `perusahaan`) VALUES
(4, 'CV. Barokah Adhi Jaya'),
(5, 'CV. JAYA WIBOWO'),
(1, 'CV. Naga Kencana Wiratama'),
(3, 'CV.Jehovah Jireh'),
(2, 'PT. EXTRACON DWI MITRA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `paket`
--
ALTER TABLE `paket`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_paket` (`nama_paket`);

--
-- Indexes for table `penawaran`
--
ALTER TABLE `penawaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `perusahaan` (`perusahaan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `paket`
--
ALTER TABLE `paket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `penawaran`
--
ALTER TABLE `penawaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
