<?php
require "koneksi.php";

// ambil data paket
$id_paket = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM paket WHERE id = '$id_paket'");
$paket = mysqli_fetch_assoc($query);


// simpan penawaran
if (isset($_POST['kirim'])) {


    $nama_rekanan = $_POST['nama_rekanan'];
    $harga_penawaran = $_POST['harga_penawaran'];
    $nama_paket = $paket['nama_paket'];

   $cek = mysqli_query($koneksi, "
    SELECT harga_awal 
    FROM paket 
    WHERE id = '$id_paket'
");

$data = mysqli_fetch_assoc($cek);

if ($harga_penawaran > $data['harga_awal']) {
    $pesan = "❌ Harga penawaran tidak boleh lebih besar dari harga pagu.";
} else {
    $insert = mysqli_query($koneksi, "
        INSERT INTO penawaran (nama_rekanan, nama_paket, harga_penawaran)
        VALUES ('$nama_rekanan', '$nama_paket', '$harga_penawaran')
    ");

    if ($insert) {
        $pesan = "✅ Penawaran berhasil dikirim.";
        header("Refresh:1; url=index.php");
    }
}
         
   
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Form Penawaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h5>Form Penawaran</h5>
        </div>

        <div class="card-body">
  <?php if (!empty($pesan)) : ?>
                <div class="alert alert-info"><?= $pesan ?></div>
            <?php endif; ?>
            <form method="POST">

          

                <div class="mb-3">
                    <label>Nama Paket</label>
                 <input type="text" class="form-control" value="<?= $paket['nama_paket'] ?>" readonly>
                </div>
  <div class="mb-3">
                    <label>Satuan Kerja</label>
                 <input type="text" class="form-control" value="<?= $paket['satuan_kerja'] ?>" readonly>
                </div>


                  <div class="mb-3">
                              <label>Syarat Sub bidang</label>
                 <input type="text" class="form-control" value="<?= $paket['sub_bidang'] ?>" readonly>
                </div>

                     <div class="mb-3">
                        <label>Harga Pagu</label>
               <input type="text" class="form-control" value="<?= number_format($paket['harga_awal']) ?>" readonly>
       </div>

                      <div class="mb-3">
                    <label>Nama Rekanan</label>
                    <select name="nama_rekanan" class="form-control" required>
                        <option value="">-- Pilih Rekanan --</option>
                        <?php
                        $q = mysqli_query($koneksi, "SELECT perusahaan FROM users");
                        while ($r = mysqli_fetch_assoc($q)) {
                            echo "<option value='{$r['perusahaan']}'>{$r['perusahaan']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Harga Penawaran</label>
                    <input type="number" name="harga_penawaran" class="form-control" required>
                </div>


                <button type="submit" name="kirim" class="btn btn-success">
                    Kirim Penawaran
                </button>

            </form>

        </div>
    </div>
</div>

</body>
</html>
