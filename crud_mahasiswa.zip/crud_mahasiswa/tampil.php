<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Data Mahasiswa Baru</title>
  
  <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'koneksi.php'; ?>

<div class="container">
    <h2>Tambah Data Mahasiswa</h2>

    <form method="post" action="proses_tambah.php" class="form-box">
      <label>ID</label>
      <input type="text" name="id">

      <label>Nama</label>
      <input type="text" name="nama">

      <label>NIM</label>
      <input type="text" name="nim">

      <label>Jurusan</label>
      <input type="text" name="jurusan">

      <button type="submit">Simpan</button>
    </form>
</div>

<div class="container">
<h2>Daftar Mahasiswa</h2>

<?php
$result = mysqli_query($conn, "SELECT * FROM mahasiswa");
?>

<table>
    <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>NIM</th>
        <th>Jurusan</th>
        <th>Aksi</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= $row['nama']; ?></td>
            <td><?= $row['nim']; ?></td>
            <td><?= $row['jurusan']; ?></td>
            <td>
                <a class="btn-edit" href="edit.php?id=<?= $row['id']; ?>">Edit</a>
                <a class="btn-delete" href="hapus.php?id=<?= $row['id']; ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</div>

</body>
</html>
