<?php
include 'koneksi.php';

$id = mysqli_real_escape_string($conn, $_POST['id']);
$nama = mysqli_real_escape_string($conn, $_POST['nama']);
$nim = mysqli_real_escape_string($conn, $_POST['nim']);
$jurusan = mysqli_real_escape_string($conn, $_POST['jurusan']);

$sql = "INSERT INTO mahasiswa (id, nama, nim, jurusan)
        VALUES ('$id', '$nama', '$nim', '$jurusan')";

if (mysqli_query($conn, $sql)) {
    echo "<script>alert('Data berhasil disimpan'); window.location='tampil.php';</script>";
} else {
    echo "Gagal menyimpan: " . mysqli_error($conn);
}
?>
