<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php
include 'koneksi.php';
$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM mahasiswa WHERE id='$id'");
$row = mysqli_fetch_assoc($data);
?>

<div class="container">

<h2>Edit Data Mahasiswa</h2>

<form method="post" action="proses_edit.php" class="form-box">
    <input type="hidden" name="id" value="<?= $row['id']; ?>">

    <label>Nama</label>
    <input type="text" name="nama" value="<?= $row['nama']; ?>">

    <label>NIM</label>
    <input type="text" name="nim" value="<?= $row['nim']; ?>">

    <label>Jurusan</label>
    <input type="text" name="jurusan" value="<?= $row['jurusan']; ?>">

    <button type="submit" name="submit">Update</button>
</form>

</div>

</body>
</html>
