<?php
include 'koneksi.php';

if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $jurusan = $_POST['jurusan'];

    $sql = "UPDATE mahasiswa SET 
            nama='$nama',
            nim='$nim',
            jurusan='$jurusan'
            WHERE id='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Data berhasil diupdate'); window.location='tampil.php';</script>";
    } else {
        echo "Gagal update!";
    }
}
?>
