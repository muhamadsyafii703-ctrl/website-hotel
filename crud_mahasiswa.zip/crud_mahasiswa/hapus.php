<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    mysqli_query($conn, "DELETE FROM mahasiswa WHERE id='$id'");
}

header("Location: tampil.php");
exit();
?>
