<?php include 'header.php'; ?>
<h3>Dashboard Admin</h3>

<ul class="list-group">
    <li class="list-group-item">
        <a href="antrian.php?id_poli=1">Antrian Poli Umum</a>
    </li>
    <li class="list-group-item">
        <a href="antrian.php?id_poli=2">Antrian Poli Gigi</a>
    </li>
     <li class="list-group-item">
        <a href="antrian.php?id_poli=3">Antrian Poli Mata</a>
    </li>
</ul>
<footer class="text-center text-muted mt-5 mb-3">
    <hr>
    © 2026 Sistem Pendaftaran Pasien
</footer>
