<?php
include '../config/koneksi.php';

$id = $_GET['id'];

$data = mysqli_query($conn, "SELECT id_poli FROM pendaftaran WHERE id_pendaftaran=$id");
$row  = mysqli_fetch_assoc($data);

mysqli_query($conn, "DELETE FROM pendaftaran WHERE id_pendaftaran=$id");

header("Location: antrian.php?id_poli=".$row['id_poli']);
?>
