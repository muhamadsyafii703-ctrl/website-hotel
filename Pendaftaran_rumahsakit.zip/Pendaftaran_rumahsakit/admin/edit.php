<?php
include '../config/koneksi.php';
include 'header.php';

$id = $_GET['id'];

$data = mysqli_query($conn, "SELECT * FROM pendaftaran WHERE id_pendaftaran = $id");
$row  = mysqli_fetch_assoc($data);

if (isset($_POST['update'])) {
    $status = $_POST['status'];
    mysqli_query($conn, "UPDATE pendaftaran SET status='$status' WHERE id_pendaftaran=$id");
    header("Location: antrian.php?id_poli=".$row['id_poli']);
}
?>

<h3>Edit Status Antrian</h3>

<form method="post">
    <div class="mb-3">
        <label>Status</label>
        <select name="status" class="form-control">
            <option <?= $row['status']=='Menunggu'?'selected':''; ?>>Menunggu</option>
            <option <?= $row['status']=='Diproses'?'selected':''; ?>>Diproses</option>
            <option <?= $row['status']=='Selesai'?'selected':''; ?>>Selesai</option>
        </select>
    </div>
    <button name="update" class="btn btn-primary">Simpan</button>
    <a href="antrian.php?id_poli=<?= $row['id_poli']; ?>" class="btn btn-secondary">Batal</a>
</form>
<footer class="text-center text-muted mt-5 mb-3">
    <hr>
    © 2026 Sistem Pendaftaran Pasien
