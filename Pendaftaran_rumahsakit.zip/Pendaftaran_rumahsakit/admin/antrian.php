<?php
include '../config/koneksi.php';

/* =========================
   AMBIL ID POLI DARI URL
   ========================= */
if (!isset($_GET['id_poli'])) {
    die("ID poli tidak ditemukan");
}

$id_poli = (int) $_GET['id_poli'];

/* =========================
   AMBIL NAMA POLI
   ========================= */
$poliQ = mysqli_query($conn, "SELECT nama_poli FROM poli WHERE id_poli='$id_poli'");
$poliD = mysqli_fetch_assoc($poliQ);
$nama_poli = $poliD['nama_poli'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Antrian <?= $nama_poli; ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#f4f6f9;
    font-family: Arial, Helvetica, sans-serif;
}
.card{
    border:none;
    box-shadow:0 4px 12px rgba(0,0,0,.08);
}
.table thead{
    background:#0d6efd;
    color:white;
}
</style>
</head>

<body>

<div class="container mt-5">
    <h4 class="mb-3">Antrian Hari Ini - <?= $nama_poli; ?></h4>

    <div class="card">
        <div class="card-body">

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No Antrian</th>
                        <th>Nama Pasien</th>
                        <th>Status</th>
                        <th>Tanggal daftar</th>
                        <th width="180">Aksi</th>
                    </tr>
                </thead>
                <tbody>

                <?php
                $sql = "SELECT 
                            pendaftaran.id_pendaftaran,
                            pendaftaran.no_antrian,
                            pendaftaran.status,
                            pasien.nama_pasien,
                            poli.kode_poli,
                            pendaftaran.tanggal_daftar
                        FROM pendaftaran
                        JOIN pasien ON pendaftaran.id_pasien = pasien.id_pasien
                        JOIN poli ON pendaftaran.id_poli = poli.id_poli
                        WHERE pendaftaran.id_poli = '$id_poli'
                        AND pendaftaran.tanggal_daftar = CURDATE()
                        ORDER BY pendaftaran.no_antrian ASC";

                $query = mysqli_query($conn, $sql);

                if (mysqli_num_rows($query) == 0) {
                    echo "<tr><td colspan='4' class='text-center'>Belum ada antrian</td></tr>";
                }

                while ($row = mysqli_fetch_assoc($query)) {
                    $no_tampil = $row['kode_poli'] .
                                 str_pad($row['no_antrian'], 3, '0', STR_PAD_LEFT);
                ?>
                <tr>
                    <td><?= $no_tampil; ?></td>
                    <td><?= $row['nama_pasien']; ?></td>
                    <td><?= $row['status']; ?></td>
                    <td><?= $row['tanggal_daftar'] ?></td>
                    <td>
                    <?php if (trim($row['status']) !== 'Selesai') { ?>
                    <a href="edit.php?id=<?= $row['id_pendaftaran']; ?>" 
                    class="btn btn-warning btn-sm">
                    Edit
                    </a>
                <?php } ?>


                <a href="hapus.php?id=<?= $row['id_pendaftaran']; ?>" 
                class="btn btn-danger btn-sm"
                onclick="return confirm('Yakin hapus?')">
                Hapus
                </a>
                </td>
                </tr>
                <?php } ?>

                </tbody>
            </table>

            <a href="index.php" class="btn btn-secondary btn-sm">
                Kembali
            </a>

        </div>
    </div>
</div>
<footer class="text-center text-muted mt-5 mb-3">
    <hr>
    © 2026 Sistem Pendaftaran Pasien
</body>
</html>
