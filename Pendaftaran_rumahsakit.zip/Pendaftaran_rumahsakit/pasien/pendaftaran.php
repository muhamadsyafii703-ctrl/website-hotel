<?php
include '../config/koneksi.php';

$pesan_error = '';

if (isset($_POST['daftar'])) {

    $nik   = $_POST['nik'];
    $nama  = $_POST['nama'];
    $jk    = $_POST['jk'];
    $tgl   = $_POST['tgl_lahir'];
    $hp    = $_POST['no_hp'];
    $poli  = $_POST['id_poli'];

    // 1. CEK / INSERT PASIEN
    $cekPasien = mysqli_query($conn, "SELECT id_pasien FROM pasien WHERE nik='$nik'");
    if (mysqli_num_rows($cekPasien) > 0) {  
        $pasien = mysqli_fetch_assoc($cekPasien);
        $id_pasien = $pasien['id_pasien'];
    } else {
        mysqli_query($conn, "
            INSERT INTO pasien (nik,nama_pasien,jenis_kelamin,tanggal_lahir,no_hp)
            VALUES ('$nik','$nama','$jk','$tgl','$hp')
        ");
        $id_pasien = mysqli_insert_id($conn);
    }

    // 2. CEK SUDAH DAFTAR DI POLI & HARI YANG SAMA
    $cekHariIni = mysqli_query($conn, "
        SELECT id_pendaftaran FROM pendaftaran
        WHERE id_pasien = $id_pasien
        AND id_poli = $poli
        AND tanggal_daftar = CURDATE()
    ");

    if (mysqli_num_rows($cekHariIni) > 0) {

        $pesan_error = "Pasien sudah terdaftar di poli ini hari ini.";

    } else {

        // 3. HITUNG NOMOR ANTRIAN
        $q = mysqli_query($conn, "
            SELECT MAX(no_antrian) AS terakhir
            FROM pendaftaran
            WHERE id_poli = $poli
            AND tanggal_daftar = CURDATE()
        ");
        $data = mysqli_fetch_assoc($q);
        $no_antrian = ($data['terakhir'] == null) ? 1 : $data['terakhir'] + 1;

        // 4. SIMPAN PENDAFTARAN
        mysqli_query($conn, "
            INSERT INTO pendaftaran (id_pasien,id_poli,tanggal_daftar,no_antrian,status)
            VALUES ($id_pasien,$poli,CURDATE(),$no_antrian,'Menunggu')
        ");

        // 5. REDIRECT (ANTI RELOAD)
        header("Location: sukses.php?antrian=$no_antrian&id_poli=$poli");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pendaftaran Pasien</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
        }
        .card {
            max-width: 700px;
            margin: 60px auto;
            border-radius: 10px;
            box-shadow: 0 6px 18px rgba(0,0,0,.08);
        }
        .card-header {
            background-color: #0d6efd;
            color: #fff;
            font-weight: 600;
        }
    </style>
</head>
<body>

<div class="card">
    <div class="card-header text-center">
        Form Pendaftaran Pasien
    </div>
    <div class="card-body">

        <?php if ($pesan_error != '') { ?>
        <div class="alert alert-warning text-center">
            <?= $pesan_error ?>
        </div>
        <?php } ?>

        <form method="post">
            <div class="row mb-3">
                <div class="col">
                    <label>NIK</label>
                    <input type="text" name="nik" class="form-control" required>
                </div>
                <div class="col">
                    <label>Nama Pasien</label>
                    <input type="text" name="nama" class="form-control" required>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col">
                    <label>Jenis Kelamin</label>
                    <select name="jk" class="form-control" required>
                        <option value="">-- Pilih --</option>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
                <div class="col">
                    <label>Tanggal lahir</label>
                    <input type="date" name="tgl_lahir" class="form-control" required>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col">
                    <label>No HP</label>
                    <input type="text" name="no_hp" class="form-control">
                </div>
                <div class="col">
                    <label>Pilih Poli</label>
                    <select name="id_poli" class="form-control" required>
                        <option value="">-- Pilih Poli --</option>
                        <?php
                        $poli = mysqli_query($conn, "SELECT * FROM poli");
                        while ($p = mysqli_fetch_assoc($poli)) {
                            echo "<option value='{$p['id_poli']}'>{$p['nama_poli']}</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="text-end">
                <button name="daftar" class="btn btn-primary">
                    Daftar
                </button>
            </div>
        </form>

    </div>
</div>

<footer class="text-center text-muted mt-5 mb-3">
    <hr>
    © 2026 Sistem Pendaftaran Pasien
</footer>

</body>
</html>
