<?php
include '../config/koneksi.php';

// VALIDASI PARAMETER
if (!isset($_GET['antrian']) || !isset($_GET['id_poli'])) {
    header("Location: pendaftaran.php");
    exit;
}

$no_antrian = (int) $_GET['antrian'];
$id_poli    = (int) $_GET['id_poli'];

// AMBIL DATA POLI
$q = mysqli_query($conn, "SELECT nama_poli, kode_poli,dokter FROM poli WHERE id_poli = $id_poli");
$poli = mysqli_fetch_assoc($q);

$kode_antrian = $poli['kode_poli'] . str_pad($no_antrian, 3, '0', STR_PAD_LEFT);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pendaftaran Berhasil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
        }
        .card-success {
            max-width: 420px;
            margin: 100px auto;
            border-radius: 10px;
            box-shadow: 0 6px 18px rgba(0,0,0,.08);
        }
        .card-header {
            background-color: #198754;
            color: #fff;
            text-align: center;
            font-weight: 600;
            border-radius: 10px 10px 0 0;
        }
        .antrian {
            font-size: 42px;
            font-weight: bold;
            color: #0d6efd;
            letter-spacing: 2px;
        }
    </style>
</head>
<body>

<div class="card card-success">
    <div class="card-header">
        Pendaftaran Berhasil
    </div>
    <div class="card-body text-center">
        <p class="mb-1 text-muted">Poli Tujuan</p>
        <h3 class="mb-3"><?= $poli['nama_poli']; ?></h3>
          <h3 class="mb-3"><?= $poli['dokter']; ?></h3>
        <p class="mb-1 text-muted">Nomor Antrian Anda</p>
        <div class="antrian"><?= $kode_antrian; ?></div>

        <a href="pendaftaran.php" class="btn btn-secondary mt-4">
            Kembali
        </a>
    </div>
</div>
<footer class="text-center text-muted mt-5 mb-3">
    <hr>
    © 2026 Sistem Pendaftaran Pasien
</footer>
</body>
</html>
