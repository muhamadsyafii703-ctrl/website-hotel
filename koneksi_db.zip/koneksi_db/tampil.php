<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
include 'koneksi.php';
$result = mysqli_query($conn, "SELECT * FROM mahasiswa");


echo "<h3>Daftar Mahasiswa</h3>";
echo "<table border='1'>
<tr><th>ID</th><th>Nama</th><th>NIM</th><th>Jurusan</th></tr>";


while ($row = mysqli_fetch_assoc($result)) {
  echo "<tr>
          <td>{$row['id']}</td>
          <td>{$row['nama']}</td>
          <td>{$row['nim']}</td>
          <td>{$row['jurusan']}</td>
        </tr>";
}
echo "</table>";
?>

</body>
</html>