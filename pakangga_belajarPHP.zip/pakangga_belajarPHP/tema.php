<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan Looping</title>
</head>
<body>

<form method="get">
    <input type="number" name="input1" required>
    <button type="submit">Cetak</button>
</form>

<?php
$in = isset($_GET['input1']) ? $_GET['input1'] : 0;

/* Pola angka 1 */
// $baris = 1;
// while ($baris <= $in) {
//     for ($colom = 1; $colom <= $baris; $colom++) {
//         echo "1";
//     }
//     echo "<br>";
//     $baris++;
// }

// echo "<hr>";

// /* Pola bintang */
// for ($baris = 1; $baris <= $in; $baris++) {

//     for ($kk = 0; $kk < $baris; $kk++) {
//         echo "*";
//     }
//     echo "<br>";
// }
// echo "<hr>";
// for ($baris =1 ; $baris <= $in; $baris++) {

//     for ($kk = 1; $kk <= $in; $kk++) {
//       if ($kk < $baris) {
//         echo "<span style=color:red;'>*</span>";
//       } else {
//          echo "<span style='color:black;'>*</span>";
//       }
//     }
//     echo "<br>";
// }

echo "<hr>";
for ($baris =1 ; $baris <= $in; $baris++) {

    for ($kk = 1; $kk <= $in; $kk++) {
      if ($kk <= ceil($in/2)-$baris){
        echo "<span style='color:red;'>*</span>";
      }  elseif($baris > ceil($in/2) AND $kk <= $baris-ceil($in/2)){
        echo "<span style='color:red;'>*</span>";
      }
      else {
         echo "<span style='color:black;'>*</span>";
      }
    }
    echo "<br>";
}
// echo "<hr>";
//     for ($kolom = 1; $kolom <= (2 * $baris - 1); $kolom++) {
//         if ($kolom == 1 || $kolom == (2 * $baris - 1)) {
//             echo "*";
//         } else {
//         echo "<span style='color:red;'>*</span>";

//         }
//         echo "<br>";
// }
?>

</body>
</html>
