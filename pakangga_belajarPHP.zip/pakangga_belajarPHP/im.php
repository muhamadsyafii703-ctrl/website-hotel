<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penjumlahan</title>
</head>
<body>
    <?php
    
$berhasil = true;


if($berhasil){

    echo 'selamat';

// }else{ <<< jika tidak ada yg benar 

}else{
    echo 'coba lagi';
}
    ?>

<!-- 
cara pertama -->
<!-- <?php

$score = 96;
if($score > 80 ){
    echo'<p> hadiah sepeda </p>';

}elseif($score > 60){ //max banyak
  echo'<p> hadiah sepatu </p>';

}elseif($score > 40){ 
  echo'<p> hadiah sandal </p>';
}else{ //max 1
echo'<p> coba lagi </p>';
}

?> -->




<!-- cara kedua -->
<!-- <?php
$score = 96;
if($score > 80 ){
    echo'<p> hadiah sepeda </p>';
}
if($score > 60 && $score < 81){ 
  echo'<p> hadiah sepatu </p>'; 
}
if($score > 40 && $score <61){ 
  echo'<p> hadiah sandal </p>';
}
if($score < 41){
    echo 'coba lagi';
}
?> -->


<!-- cara ketiga -->
<?php
$warna = 'hijau';

switch ($warna){
    case 'merah':
        echo '<p>berani</p>';
        break;
    case 'putih':
        echo '<p>suci</p>';
        break;
    case 'hijau':
        echo '<p>subur</p>';
        break;
    default:
        echo '<p>bukan warna</p>';
        
}
?>

<?php
// AND     A   B     OR     XOR
// F <-    T   F ->  T      T
// F <-    F   T ->  T      T
// F <-    T   T ->  T      F
// F <-    F   F ->  F      F

//ARRAY <- Dapat menampung banyak data.
//         Cukup 1 nama.
//         Masing - masing data memiliki penanda (index, key, dll).

$hewan = array('kuda','sapi','ikan');

$buah_favorite = "semangka";
$buah = ['anggur',$buah_favorite,'apel'];
$keluarga = ['ayah',1,'ibu',2,'adik',3,'kakak',4];

echo "<p> hewan favorite saya adalah $hewan[2] </p>";

for($i=0;$i<=2;$i++) // fungsi untuk perulangan.
{
    echo "<p>hewan nomer $i adalah $hewan[$i] </p>";
}


//count untuk mencari total item didalam array
for($i=0;$i< count($hewan);$i++)
{
    echo "<p>hewan nomer $i adalah $hewan[$i] </p>";
}

// echo "<p>terdapat count($hewan) hewan</p>";
echo count($hewan) ;
?>


<?php
// $hewan=[['kuda',['jantan',1],['betina',2]],['sapi',19],['ikan',10]]
$hewan=[
        ['kuda',2],
        ['sapi',19],
        ['ikan',10]
        ];

        for($i=0;$i< count($hewan);$i++)
{
echo "<p>Hewan nomer $i adalah ". $hewan[$i][0].",
        sebanyak = ", $hewan[$i][1]+3000," ekor </p>";
}

$aku = "budi";
$kamu = "siti";
$kita = $aku." ".$kamu;

echo $kita;

?>


</body>
</html>