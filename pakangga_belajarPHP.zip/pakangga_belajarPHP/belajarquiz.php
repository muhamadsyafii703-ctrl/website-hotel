<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
     <form action="" method="POST">
        <input type="number" name="input1">
        <button type="submit">cetak</button>
    </form>


   <?php
  
    $in = $_POST['input1'];


/* BAGIAN ATAS */
for ($baris = 1; $baris <= $in; $baris++) {

    // spasi
    for ($spasi = $in; $spasi > $baris; $spasi--) {
       echo "<span style='color:blue;'>*</span>";

    }

    // bintang dan spasi tengah
    for ($kolom = 1; $kolom <= (2 * $baris - 1); $kolom++) {
        if ($kolom == 1 || $kolom == (2 * $baris - 1)) {
            echo "*";
        } else {
        echo "<span style='color:red;'>*</span>";

        }
    }

    echo "<br>";
}

/* BAGIAN ATAS */
for ($baris = $in - 1 ; $baris >=1; $baris--) {

    // spasi
    for ($spasi = $in; $spasi > $baris; $spasi--) {
       echo "<span style='color:blue;'>*</span>";

    }

    // bintang dan spasi tengah
    for ($kolom = 1; $kolom <= (2 * $baris - 1); $kolom++) {
        if ($kolom == 1 || $kolom == (2 * $baris - 1)) {
            echo "*";
        } else {
        echo "<span style='color:red;'>*</span>";

        }
    }

    echo "<br>";
}

// /* BAGIAN BAWAH */
// for ($baris = $in - 1; $baris >= 1; $baris--) {

//     // spasi
//     for ($spasi = $in; $spasi > $baris; $spasi--) {
//         echo "&nbsp;&nbsp;";
//     }

//     // bintang dan spasi tengah
//     for ($kolom = 1; $kolom <= (2 * $baris - 1); $kolom++) {
//         if ($kolom == 1 || $kolom == (2 * $baris - 1)) {
//             echo "*";
//         } else {
//             echo "&nbsp;&nbsp;";
//         }
//     }

//     echo "<br>";
// }

?>


</body>
</html>