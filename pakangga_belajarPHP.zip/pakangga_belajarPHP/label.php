<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width= initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form method="get">
        <input type="number" name="input1">
        <button type="submit">Cetak</button>
    </form>

    <?php
    $in = $_GET['input1'];
    // echo"$in";
    $baris = 1;
    while ($baris <= $in) {
        for ($kolom = 1; $kolom <= $baris; $kolom++) {
            echo "*";
        }
        $baris++;
        echo "<br>";
    }

    // for($baris=1; $baris <= $in; $baris++) { 
    //     for($kolom=$in; $kolom>=$baris; $kolom--)
    // }

    for (
        $kolom = 1;
        $kolom < $in - $baris;
        $kolom++
    )

    for($kk=0; $kk < $baris; $kk++)
    {echo "<span class="putih">*</span>;}
    echo "<br>";

    ?>
</body>

</html>