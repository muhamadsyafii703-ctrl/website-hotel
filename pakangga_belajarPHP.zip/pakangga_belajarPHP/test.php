<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        .white {
            color: white;
        }
    </style>
</head>

<body>
    <form action="" method="GET">
        <input type="number" name="input1">
        <button type="submit">cetak</button>
    </form>

    <?php
    $in = $_GET['input1'];

    $baris = 1;

    for ($baris = 1; $baris <= $in; $baris++) {
        for ($kolom = 1; $kolom <= $baris; $kolom++) {
            echo "*";
        }
        echo "<br>";
    }

    ?>
    <br>

    <form action="" method="GET">
        <input type="number" name="input1">
        <button type="submit">cetak</button>
    </form>


    <?php
    if (isset($_GET['input1'])) {
        $in = $_GET['input1'];

        for ($baris = 1; $baris <= $in; $baris++) {

            for ($spasi = $in; $spasi > $baris; $spasi--) {
                echo "<span style='color:white'>*</span>";
            }           
            for ($bintang = 1; $bintang <= $baris; $bintang++) {
                echo "*";
            }
            echo "<br>";
        }
    }
    ?>
    <br>

    <form action="" method="GET">
        <input type="number" name="input1">
        <button type="submit">cetak</button>
    </form>

    <?php
if (isset($_GET['input1'])) {
    $in = $_GET['input1'];

    for ($baris = 1; $baris <= $in; $baris++) {

        
        for ($spasi = $in; $spasi > $baris; $spasi--) {
            echo "<span style='color:red'>*</span>";
        }

       
        for ($bintang = 1; $bintang <= $baris; $bintang++) {
            echo "*";
        }

        
        for ($bintang = 1; $bintang < $baris; $bintang++) {
            echo "*";
        }

        echo "<br>";
    }
}
?>

</body>

</html>