<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penjumlahan</title>
</head>
<body>
    <?php
    
$berhasil = true;


if($berhasil){

    echo 'selamat';

// }else{ <<< jika tidak ada yg benar 

}else{
    echo 'coba lagi';
}
    ?>

<!-- 
cara pertama -->
<!-- <?php

$score = 96;
if($score > 80 ){
    echo'<p> hadiah sepeda </p>';

}elseif($score > 60){ //max banyak
  echo'<p> hadiah sepatu </p>';

}elseif($score > 40){ 
  echo'<p> hadiah sandal </p>';
}else{ //max 1
echo'<p> coba lagi </p>';
}

?> -->




<!-- cara kedua -->
<!-- <?php
$score = 96;
if($score > 80 ){
    echo'<p> hadiah sepeda </p>';
}
if($score > 60 && $score < 81){ 
  echo'<p> hadiah sepatu </p>'; 
}
if($score > 40 && $score <61){ 
  echo'<p> hadiah sandal </p>';
}
if($score < 41){
    echo 'coba lagi';
}
?> -->


<!-- cara ketiga -->
<?php
$warna = 'hijau';

switch ($warna){
    case 'merah':
        echo '<p>berani</p>';
        break;
    case 'putih':
        echo '<p>suci</p>';
        break;
    case 'hijau':
        echo '<p>subur</p>';
        break;
    default:
        echo '<p>bukan warna</p>';
        
}
?>



</body>
</html>