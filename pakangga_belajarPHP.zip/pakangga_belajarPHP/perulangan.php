<?php 
$kekuatan = 0;
$kekuatanmaks = 17;

// $buah = ["apel", "jeruk", "mangga"];

// foreach ($buah as $item) {
//     echo $item . "<br>";
// }

// echo "menggunakan Do While </br>";
// do {
//     echo "kekuatanmu $kekuatan <br>";
//     $kekuatan++;
// } while ($kekuatan <= $kekuatanmaks);
  
echo "menggunakan For </br>";
for ($kekuatan; $kekuatan <= $kekuatanmaks ; $kekuatan ++) { 
     echo "Kekuatanmu:".$kekuatan. "<br>";
}

// echo "menggunakan While </br>";
// while ($kekuatan < $kekuatanmaks) {
//     $kekuatan = $kekuatan + 1;
//     echo "Kekuatanmu:".$kekuatan. "<br>";
   
// }
?>