<?php 
$pelaku = "Bagas";
$umur = 3;


for ($i = 1; $i <= 50; $i++) {

    if ($i % 5 == 0) {
        // Jika kelipatan 5 → warna merah
        echo "<span style='color:red;'>$i</span><br>";
    } else {
        // Selain itu → warna normal
        echo "$i<br>";
    }

}
?>
<?php
// switch ($umur) {
//     case 1:
//     echo $pelaku. "hanya boleh minum susu";
//     break;

//     case 2:
//     echo $pelaku. "hanya boleh makan makanan yang lembut";
//     break;

//     case 3:
//     echo $pelaku. "sudah boleh makan sepuasnya";
//     break;

//     default:
//     echo $pelaku. "masih kanak kanak";
//     break;
// }


// if ($umur <18 ) {
 // echo $pelaku. "Tidak boleh merokok";
// } elseif ($umur >= 18) {
  //  echo $pelaku. "Boleh merokok";
// } else {
 //   echo $pelaku. "masih bocil";
// }

?>