<?php
$hero = 0;
$level = 15;

// for ($hero=0; $hero <= $level ; $hero++) { 
//   echo "Karakter ini levelnya sudah $hero <br>";
// }

// do {
//   echo "Karakter ini levelnya sudah $hero <br>";
//   $hero++;
// } while ($hero <= $level);

// while ($hero < $level) {
//       $level = $level + 1;
//   echo "Karakter ini levelnya sudah $hero <br>";
// }


$club = array("Arema", "Persija", "persib");
foreach ($club as $key => $value) {
  echo "saya menyukai club indonesia $value <br>";
}

?>
