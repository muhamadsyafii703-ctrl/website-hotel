<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php

//kode paten
$db = "db_latihan";
$username = "root";
$password = "";
$server = "localhost";

try{
    $con = new PDO("mysql:host=$server;
    dbname=$db;chartset=utf8",$username,$password);
    $con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);


}catch(PDOException $e){
 die("error: ".$e->getMessage()) ; 
}

$perintah = $con->prepare("select id,nama,nim,jurusan 
from mahasiswa");
$perintah->execute();
$mahasiswa = $perintah->fetchAll(PDO::FETCH_ASSOC);

//kode paten


echo "<table border='1'><tr> <th>NIM </th><th>NAMA </th></tr>";
foreach ($mahasiswa as $d){
    echo "<tr><td>$d[nim]</td><td>$d[nama]</td></tr>";
}
echo "</table>";


?>

<?php


$mahasiswa = [[1,"A"],[2,"B"],[3,"C"],[4,"D"]];

echo "<table border='1'><tr> <th>NIM </th><th>NAMA </th></tr>";

foreach ($mahasiswa as $d){
    echo "<tr><td>$d[0]</td><td>$d[1]</td></tr>";
}
echo "</table>";
?>
</body>
</html>