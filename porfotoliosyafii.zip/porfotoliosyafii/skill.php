<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skill</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php include('menu.php'); ?>

    <div class="container">
        <h2>Skill / Keahlian</h2>
        <ol type="1">
            <li>HTML, CSS (Pemula)</li>
            <li>Microsoft Office (Word, Excel, PowerPoint)</li>
            <li>Editing Gambar (Canva, Photoshop, Coreldraw)</li>
            <li>Photografy dan Videografy</li>
            <li>Public Speaking</li>
        </ol>
    </div>

</body>
</html>
