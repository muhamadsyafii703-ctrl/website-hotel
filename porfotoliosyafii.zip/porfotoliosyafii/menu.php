<nav>
    <ul>
        <li><a href="beranda.php">Beranda</a></li>
        <li><a href="index.php">Data Diri</a></li>
        <li><a href="pendidikan.php">Riwayat Pendidikan</a></li>
        <li><a href="skill.php">Skill</a></li>
    </ul>
</nav>