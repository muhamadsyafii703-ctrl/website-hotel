<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Porfotolio Saya</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>

    <?php include('menu.php'); ?>

    <div class="container">
        <h2>Data Diri</h2>
        <p><strong>Nama:</strong> Muhamad Syafi'i Asyari</p>
        <p><strong>Tempat, Tanggal Lahir:</strong> Jombang, 03 Februari 2007</p>
        <p><strong>Alamat:</strong> Jl. Trunojoyo no 02 Godong, Genukwatu</p>
        <p><strong>Email:</strong> syafii@gmail.com</p>
    </div>

</body>
</html>

