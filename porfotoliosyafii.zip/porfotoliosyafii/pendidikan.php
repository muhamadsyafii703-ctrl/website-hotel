<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pendidikan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php include('menu.php'); ?>

    <div class="container">
        <h2>Riwayat Pendidikan</h2>
        <ul>
            <li>MI Islamiyah Genukwatu (2011 - 2018)</li>
            <li>MTS Bahrul Ulum Genukwatu (2018 - 2021)</li>
            <li>SMK Ma'arif Ngoro (2021 - 2025)</li>
            <li>Universitas Kh.Abdul Wahab Khasbullah - S1 Informatika (2025 - Sekarang)</li>
        </ul>
    </div>

</body>
</html>