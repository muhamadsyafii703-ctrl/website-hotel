<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
  
    <?php 
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = mysqli_real_escape_string($conn, $_POST['id']);

} elseif (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
}

if (!empty($id)) {
    $sql = "DELETE FROM mahasiswa WHERE id = '$id'";
    mysqli_query($conn, $sql);
    header("Location: tampil.php");
    exit();
}
?>


</form>
</body>
</html>