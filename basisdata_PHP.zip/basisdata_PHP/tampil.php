<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="style.css"> 
</head>
<body>
    <div class="container">
    <form method="post" action="proses_tambah.php">
      Id: <input type="text" name="id"></br>
      Nama: <input type="text" name="nama"><br>
      NIM: <input type="text" name="nim"><br>
      Jurusan: <input type="text" name="jurusan"><br>
      <input type="submit" value="Simpan">
    </form>
    </div>
  <?php
      include 'koneksi.php';
      $result = mysqli_query($conn, "SELECT * FROM mahasiswa");
    ?>

    


     <?php
include 'koneksi.php';
$result = mysqli_query($conn, "SELECT * FROM mahasiswa");
?>

<div class="container">
<h3>Daftar Mahasiswa</h3>

<table border="1">
    <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>NIM</th>
        <th>Jurusan</th>
        <th>Aksi</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= $row['nama']; ?></td>
            <td><?= $row['nim']; ?></td>
            <td><?= $row['jurusan']; ?></td>
            <td>
                <a href="hapus.php?id=<?= $row['id']; ?>">Hapus</a> |
                <a href="edit.php?id=<?= $row['id']; ?>">Edit</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</div>


</body>
</html>
