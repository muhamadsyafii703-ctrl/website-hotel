<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  
<?php
include 'koneksi.php';
$id = mysqli_real_escape_string($conn, $_POST['id']);
$nama = mysqli_real_escape_string($conn, $_POST['nama']);
$nim = mysqli_real_escape_string($conn, $_POST['nim']);
$jurusan = mysqli_real_escape_string($conn, $_POST['jurusan']);


$sql="INSERT INTO mahasiswa (id, nama, nim, jurusan)
     VALUES ('$id', '$nama', '$nim', '$jurusan')";

if (mysqli_query($conn, $sql)) {
  echo "Data berhasil di simpan. <a href= 'tampil.php'>Lihat Data</a>";
} else {
  echo "Gagal:" . mysqli_error($conn);
}


?>

</body>
</html>