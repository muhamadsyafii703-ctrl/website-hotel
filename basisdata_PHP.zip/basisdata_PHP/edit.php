<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $jurusan = $_POST['jurusan'];

    $update = mysqli_query($conn, "UPDATE mahasiswa SET
                                    id='$id',
                                    nim='$nim',
                                    nama='$nama',
                                    jurusan='$jurusan'
                                   WHERE id=$id");

    echo $update 
        ? "<script>alert('Berhasil diupdate'); window.location='tampil.php';</script>"
        : "Gagal update!";
}
?>
</body>
</html>