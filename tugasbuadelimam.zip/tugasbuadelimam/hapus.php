<?php
include 'config.php';

$id = $_GET['id'];

$delete = mysqli_query($conn, "DELETE FROM siswa WHERE id=$id");

if ($delete) {
    echo "<script>alert('Data berhasil dihapus'); window.location='index.php';</script>";
} else {
    echo "Gagal menghapus data";
}
?>