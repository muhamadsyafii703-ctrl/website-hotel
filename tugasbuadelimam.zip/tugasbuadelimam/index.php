<?php include 'config.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Data siswa</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background: #f2f2f2;
        margin: 0;
        padding: 20px;
    }

    h2 {
        background: #4CAF50;
        color: white;
        padding: 10px;
        border-radius: 5px;
        display: inline-block;
    }

    .container {
        background: white;
        padding: 20px;
        border-radius: 8px;
        max-width: 700px;
        margin: auto;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    a.button {
        background: #4CAF50;
        color: white;
        padding: 10px 15px;
        text-decoration: none;
        border-radius: 5px;
        margin-bottom: 10px;
        display: inline-block;
    }
    a.button:hover {
        background: #45a049;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }

    th {
        background: #4CAF50;
        color: white;
        padding: 10px;
    }

    td {
        padding: 10px;
        background: #fafafa;
        border-bottom: 1px solid #ddd;
    }

    td a {
        color: #2196F3;
        text-decoration: none;
    }
    td a:hover {
        text-decoration: underline;
    }

    input[type="text"], input[type="number"] {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        margin-bottom: 15px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    button {
        padding: 10px 15px;
        background: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    button:hover {
        background: #45a049;
    }
</style>
</head>
<body>

<div class="container">

<h2>Daftar siswa</h2>

<a href="tambah.php" class="button">+ Tambah siswa</a>

<table>
    <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>Nisn</th>
        <th>Jurusan</th>
        <th>Aksi</th>
    </tr>

    <?php
    $query = mysqli_query($conn, "SELECT * FROM siswa ORDER BY id DESC");
    while ($row = mysqli_fetch_assoc($query)) {
    ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['Nama'] ?></td>
            <td><?= $row['Nisn'] ?></td>
            <td><?= $row['Jurusan'] ?></td>
            <td>
                <a href="edit.php?id=<?= $row['id'] ?>">Edit</a> |
                <a href="hapus.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin?')">Hapus</a>
            </td>
        </tr>
    <?php } ?>
</table>

</div>

</body>
</html>