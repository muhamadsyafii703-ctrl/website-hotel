<?php
include 'config.php';
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM siswa WHERE id=$id"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit siswa</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background: #f2f2f2;
        margin: 0;
        padding: 20px;
    }

    h2 {
        background: #4CAF50;
        color: white;
        padding: 10px;
        border-radius: 5px;
        display: inline-block;
    }

    .container {
        background: white;
        padding: 20px;
        border-radius: 8px;
        max-width: 700px;
        margin: auto;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    a.button {
        background: #4CAF50;
        color: white;
        padding: 10px 15px;
        text-decoration: none;
        border-radius: 5px;
        margin-bottom: 10px;
        display: inline-block;
    }
    a.button:hover {
        background: #45a049;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }

    th {
        background: #4CAF50;
        color: white;
        padding: 10px;
    }

    td {
        padding: 10px;
        background: #fafafa;
        border-bottom: 1px solid #ddd;
    }

    td a {
        color: #2196F3;
        text-decoration: none;
    }
    td a:hover {
        text-decoration: underline;
    }

    input[type="text"], input[type="number"] {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        margin-bottom: 15px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    button {
        padding: 10px 15px;
        background: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    button:hover {
        background: #45a049;
    }
</style>
</head>
<body>

<div class="container">

<h2>Edit Data siswa</h2>

<form method="POST">
    <label>id:</label>
    <input type="text" name="id" value="<?= $data['id'] ?>" required>

    <label>Nama:</label>
    <input type="text" name="Nama" value="<?= $data['Nama'] ?>" required>

    <label>Nisn:</label>
    <input type="text" name="Nisn" value="<?= $data['Nisn'] ?>" required>

    <label>Jurusan:</label>
    <input type="text" name="Jurusan" value="<?= $data['Jurusan'] ?>" required>

    <button type="submit" name="submit">Update</button>
</form>

<?php
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $nama = $_POST['Nama'];
    $nisn = $_POST['Nisn'];
    $jurusan = $_POST['Jurusan'];

    $update = mysqli_query($conn, "UPDATE siswa SET
                                    id='$id',
                                    nama'$nama',
                                    nisn='$nisn',
                                    jurusan='$jurusan'
                                   WHERE id=$id");

    echo $update 
        ? "<script>alert('Berhasil diupdate'); window.location='index.php';</script>"
        : "Gagal update!";
}
?>

</div>

</body>
</html>