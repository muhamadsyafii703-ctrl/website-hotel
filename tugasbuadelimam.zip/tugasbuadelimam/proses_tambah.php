<?php
session_start();
if (!empty($_SESSION['errors'])) {
    foreach ($_SESSION['errors'] as $e) {
        echo "<p style='color:red;'>".htmlspecialchars($e)."</p>";
    }
    unset($_SESSION['errors']);
}
if (!empty($_SESSION['success'])) {
    echo "<p style='color:green;'>".htmlspecialchars($_SESSION['success'])."</p>";
    unset($_SESSION['success']);
}
?>
