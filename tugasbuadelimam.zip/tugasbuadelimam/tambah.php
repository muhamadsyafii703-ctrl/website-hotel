<?php include 'config.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah siswa</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background: #f2f2f2;
        margin: 0;
        padding: 20px;
    }

    h2 {
        background: #4CAF50;
        color: white;
        padding: 10px;
        border-radius: 5px;
        display: inline-block;
    }

    .container {
        background: white;
        padding: 20px;
        border-radius: 8px;
        max-width: 700px;
        margin: auto;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    a.button {
        background: #4CAF50;
        color: white;
        padding: 10px 15px;
        text-decoration: none;
        border-radius: 5px;
        margin-bottom: 10px;
        display: inline-block;
    }
    a.button:hover {
        background: #45a049;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }

    th {
        background: #4CAF50;
        color: white;
        padding: 10px;
    }

    td {
        padding: 10px;
        background: #fafafa;
        border-bottom: 1px solid #ddd;
    }

    td a {
        color: #2196F3;
        text-decoration: none;
    }
    td a:hover {
        text-decoration: underline;
    }

    input[type="text"], input[type="number"] {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        margin-bottom: 15px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    button {
        padding: 10px 15px;
        background: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    button:hover {
        background: #45a049;
    }
</style>
</head>
<body>

<div class="container">

<h2>Tambah Data siswa</h2>

<form method="POST">
    <label>Id:</label>
    <input type="text" name="Id" required>

    <label>Nama:</label>
    <input type="text" name="nama" required>

    <label>Nisn:</label>
    <input type="text" name="nisn" required>

    <label>Jurusan:</label>
    <input type="text" name="jurusan" required>

    <button type="submit" name="submit">Simpan</button>
</form>

<?php
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $nisn = $_POST['nisn'];
    $jurusan = $_POST['jurusan'];

    $insert = mysqli_query($conn, "INSERT INTO siswa (id, nama, nisn, jurusan)
                                  VALUES ('$id', '$nama', '$nisn', '$jurusan')");

    echo $insert
        ? "<script>alert('Berhasil'); window.location='index.php';</script>"
        : "Gagal menyimpan data!";
}
?>

</div>

</body>
</html>
