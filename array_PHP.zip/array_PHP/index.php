<?php 
$hewan= array('kuda','sapi','ikan');

$favorit = "bola";
$hobi= array('bulutagkis',$favorit,'bacabuku');

$keluarga=['ayah',1,'ibu',2,'kakak',3];
echo "<p> hewan favorit saya adalah $hewan [1]</p>";

for ($1=0;$1 <=2;$1++){
    echo "<p>hewan nomer $1 adalah $hewan [1]</p>";
}
?>
