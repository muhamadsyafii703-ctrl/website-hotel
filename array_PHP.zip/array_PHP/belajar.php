<?php 
$hewan = array ('kuda','sapi','ikan');

for ($i=0 $i <count($hewan);si++){
    echo "<p>hewan nomer $i adalah $hewan [$i]</p>";
}
?>