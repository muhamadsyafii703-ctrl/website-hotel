<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pengenalan Pemrograman</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Pengenalan Pemrograman</a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#php">Pengenalan PHP</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#project">Project</a>
                </li>
            </ul>

            <form class="d-flex">
                <input class="form-control me-2" type="search" placeholder="Search">
                <button class="btn btn-outline-light" type="submit">Search</button>
            </form>
        </div>
    </div>
</nav>

<!-- CAROUSEL -->
 <style>
.carousel-item img {
    height: 350px;     
    object-fit: cover; 
}
</style>

<div id="carouselExampleIndicators" class="carousel slide mt-5">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="0" class="active"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="2"></button>
    </div>

    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://cdn.pixabay.com/photo/2015/09/05/20/02/coding-924920_640.jpg"
                class="d-block w-100" alt="">
        </div>
        <div class="carousel-item">
            <img src="https://wallpapers.com/images/hd/h-t-m-l5-logo-code-background-cydiccu67u1xq2om.jpg"
                class="d-block w-100" alt="">
        </div>
        <div class="carousel-item">
            <img src="https://img.freepik.com/premium-photo/php-programming-text_272306-140.jpg"
                class="d-block w-100" alt="">
        </div>
    </div>

    <button class="carousel-control-prev" type="button"
        data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>

    <button class="carousel-control-next" type="button"
        data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>
</div>

<!-- SECTION PHP -->
</style>
<section class="container my-5" id="php">
    <h1 class="text-center mb-4">Pengenalan PHP</h1>
    <img src="https://images.unsplash.com/photo-1599507593362-50fa53ed1b40"
        class="img-fluid mb-4" alt="PHP">

    <p>
        PHP (Hypertext Preprocessor) adalah bahasa pemrograman server-side yang digunakan
        untuk membangun aplikasi web dinamis. PHP bekerja di sisi server untuk memproses
        permintaan, mengakses database, hingga menghasilkan output HTML yang ditampilkan
        di browser. Karena mudah dipelajari dan memiliki komunitas besar, PHP banyak
        digunakan dalam sistem informasi, e-commerce, dan CMS seperti WordPress.
    </p>
</section>

<!-- SECTION PROJECT -->
<section class="container my-5" id="project">
    <h1 class="text-center mb-4">Project</h1>

    <div class="row justify-content-center gap-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">latihan 1</h5>
                    <p class="card-text">Menampilkan teks</p>
                    <a href="/tesboostrap/project/latihan1.html" class="btn btn-primary">
                        Lihat Project
                    </a>
                </div>
            </div>
        </div>

         <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">latihan 2</h5>
                    <p class="card-text">Variabel dan Operator</p>
                    <a href="/tesboostrap/project/latihan2.html" class="btn btn-primary">
                        Lihat Project
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">latihan 3</h5>
                    <p class="card-text">Struktur Kondisi 1</p>
                    <a href="/tesboostrap/project/latihan3.html" class="btn btn-primary">
                        Lihat Project
                    </a>
                </div>
            </div>
        </div>

           <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">latihan 4</h5>
                    <p class="card-text">Struktur Kondisi 2</p>
                    <a href="/tesboostrap/project/latihan4.html" class="btn btn-primary">
                        Lihat Project
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">latihan 5</h5>
                    <p class="card-text">Input Data</p>
                    <a href="/tesboostrap/project/latihan5.html" class="btn btn-primary">
                        Lihat Project
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">latihan 6</h5>
                    <p class="card-text">Koneksi Database</p>
                    <a href="/tesboostrap/project/latihan6.html" class="btn btn-primary">
                        Lihat Project
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">latihan 7</h5>
                    <p class="card-text">CRUD</p>
                    <a href="/tesboostrap/project/latihan7.html" class="btn btn-primary">
                        Lihat Project
                    </a>
                </div>
            </div>
        </div>
        
    </div>
</section>


<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('.project-btn').forEach(button => {
    button.addEventListener('click', function () {
        window.location.href = this.dataset.link;
    });
});
</script>


</body>
</html>
